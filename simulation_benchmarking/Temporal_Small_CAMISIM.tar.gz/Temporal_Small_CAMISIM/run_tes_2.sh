#!/bin/bash

out="/Users/cameronmartino/bin/TesasSemble-benchmarking/species_resolution_small_simulation/tes_out"
in="/Users/cameronmartino/bin/TesasSemble-benchmarking/species_resolution_small_simulation/tes_reads/fasta"

# all spades kmers 21,33,55,77,99,127
for kmerlen in 140; do
    mkdir $out/$kmerlen
    echo $kmerlen
    python /Users/cameronmartino/bin/TesasSemble/scripts/run_optim.py -i fraction -e 1 --optim-type simulated_annealing --alpha=0.5 -r $kmerlen --k 3 --files $in/*.fasta --output-dir $out/$kmerlen
done
