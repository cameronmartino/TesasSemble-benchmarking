#!/bin/bash

out="/Users/cameronmartino/bin/species_resolution_small_simulation/tes_out"
in="/Users/cameronmartino/bin/species_resolution_small_simulation/fasta"

# all spades kmers 21,33,55,77,99,127
for kmerlen in 33 ; do
    mkdir $out/$kmerlen
    echo $kmerlen
    python /Users/cameronmartino/bin/TesasSemble/scripts/run_optim.py -e 10 --files $in/*.fasta --optim-type simulated_annealing --output-dir $out/$kmerlen --alpha=0.5 -r $kmerlen --k 7
done
